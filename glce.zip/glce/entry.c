/**
 * @file entry.c
 * @author chocolate-pie24
 * @brief ゲームアプリケーションエントリーポイント
 * @version 0.1
 * @date 2025-09-20
 *
 * @copyright Copyright (c) 2025 chocolate-pie24
 *
 * @par License
 * MIT License. See LICENSE file in the project root for full license text.
 *
 */
#include <stdint.h>
#include <stdio.h>

#include "application/application.h"

#include "engine/base/choco_message.h"

#ifdef TEST_BUILD   // TODO: test用のmainを用意して別に移す

// test: application/core
#include "application/core/test_application_err_utils.h"

// test: application/command_interpreter
#include "application/command_interpreter/test_flight_camera.h"

// test: engine/base
#include "engine/base/choco_math/test_choco_math.h"

// test: engine/core
#include "engine/core/memory/test_linear_allocator.h"
#include "engine/core/memory/test_choco_memory.h"
#include "engine/core/filesystem/test_filesystem.h"
#include "engine/core/buffer_utils/test_buffer_utils.h"
#include "engine/core/geometry_primitive/test_aabb_3d.h"
#include "engine/core/geometry_primitive/test_geometry_primitive_err_utils.h"

// test: engine/containers
#include "engine/containers/test_choco_string.h"
#include "engine/containers/test_ring_queue.h"

// test: engine/io_utils
#include "engine/io_utils/test_fs_utils.h"

// test: engine/resource
#include "engine/resource/core/test_resource_err_utils.h"
#include "engine/resource/loaders/test_bmp_loader.h"
#include "engine/resource/loaders/test_stl_loader.h"
#include "engine/resource/texture/test_texture.h"
#include "engine/resource/geometry/test_lit_mesh_geometry.h"
#include "engine/resource/geometry/test_line_mesh_geometry.h"
#include "engine/resource/geometry/test_point_mesh_geometry.h"
#include "engine/resource/geometry/test_ui_mesh_geometry.h"

// test: engine/systems/platform
#include "engine/systems/platform/core/test_platform_err_utils.h"
#include "engine/systems/platform/platform_concretes/test_platform_glfw.h"
#include "engine/systems/platform/test_platform_context.h"

// test: engine/systems/camera_system
#include "engine/systems/camera_system/camera_core/test_camera_err_utils.h"
#include "engine/systems/camera_system/camera_core/test_camera_memory.h"
#include "engine/systems/camera_system/camera/test_camera.h"
#include "engine/systems/camera_system/camera_controller/test_flight_camera_controller.h"
#include "engine/systems/camera_system/camera_manager/test_camera_manager.h"

// test: engine/systems/renderer
#include "engine/systems/renderer/core/test_renderer_err_utils.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/test_concrete_shader.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/test_concrete_vao.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/test_concrete_vbo.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/test_concrete_texture.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_context/test_context_shader.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_context/test_context_vao.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_context/test_context_vbo.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_context/test_context_texture.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_context/test_renderer_backend_context.h"

// test: engine/systems/texture_system
#include "engine/systems/texture_system/test_texture_manager.h"

#endif

/**
 * @brief ゲームアプリケーションメイン
 *
 * @param[in] argc_ 引数の個数
 * @param[in] argv_ 引数
 *
 * @return int
 */
int main(int argc_, char** argv_) {
    (void)argc_;
    (void)argv_;
#ifdef RELEASE_BUILD
    INFO_MESSAGE("Build mode: RELEASE.");
#endif
#ifdef DEBUG_BUILD
    INFO_MESSAGE("Build mode: DEBUG.");
#endif
#ifdef TEST_BUILD
    INFO_MESSAGE("Build mode: TEST.");
    for(uint8_t i = 0; i != 200; ++i) {
        message_output(100, NULL);

        // application/core
        // test_application_err_utils();

        // application/command_interpreter
        test_flight_camera();

        // engine/base
        test_choco_math();

        // engine/core
        test_linear_allocator();
        test_choco_memory();
        test_filesystem();
        test_buffer_utils();
        test_aabb_3d();
        test_geometry_primitive_err_utils();

        // engine/containers
        test_choco_string();
        test_ring_queue();

        // engine/io_utils
        test_fs_utils();

        // engine/resource
        test_resource_err_utils();
        test_bmp_loader();
        test_stl_loader();
        test_texture();
        test_lit_mesh_geometry();
        test_line_mesh_geometry();
        test_point_mesh_geometry();
        test_ui_mesh_geometry();

        // engine/camera
        test_camera_err_utils();
        test_camera_memory();
        test_camera();
        test_flight_camera_controller();
        test_camera_manager();

        // engine/platform
        test_platform_err_utils();
        test_platform_glfw();
        test_platform_context();

        // engine/renderer
        // test_renderer_err_utils();
        // test_renderer_memory();
        // test_concrete_shader();
        // test_concrete_vao();
        // test_concrete_vbo();
        // test_concrete_texture();
        // test_renderer_backend_context();

        // engine/texture_system
        test_texture_manager();
    }
#endif
    application_result_t app_run_result = APPLICATION_INVALID_ARGUMENT;
    application_result_t app_create_result = APPLICATION_INVALID_ARGUMENT;

    app_create_result = application_create();
    if(APPLICATION_SUCCESS != app_create_result) {
        ERROR_MESSAGE("Failed to initialize application.");
        goto cleanup;
    }

    app_run_result = application_run();
    if(APPLICATION_SUCCESS != app_run_result) {
        ERROR_MESSAGE("Failed to execute application.");
        goto cleanup;
    }

cleanup:
    application_destroy();
    return 0;
}
