/** @ingroup renderer
 *
 * @file concrete_vbo.c
 * @author chocolate-pie24
 * @brief OpenGL固有の型やAPIを使用せず、VBOを使用するためのラッパーAPIの実装
 *
 * @version 0.1
 * @date 2025-12-19
 *
 * @copyright Copyright (c) 2025 chocolate-pie24
 *
 * @par License
 * MIT License. See LICENSE file in the project root for full license text.
 *
 */
#include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/concrete_vbo.h"

#include <stddef.h>

#include <GL/glew.h>

#include "engine/base/choco_macros.h"
#include "engine/base/choco_message.h"

#include "engine/core/memory/choco_memory.h"

#include "engine/systems/renderer/core/renderer_types.h"

#include "engine/systems/renderer/renderer_backend/core/renderer_backend_types.h"
#include "engine/systems/renderer/renderer_backend/core/renderer_backend_err_utils.h"
#include "engine/systems/renderer/renderer_backend/renderer_backend_interface/interface_vbo.h"

// #define TEST_BUILD

// #ifdef TEST_BUILD
// // テスト時のみ使用するヘッダのinclude
// #include <assert.h>
// #include <string.h>

// #include "test_controller.h"

// #include "engine/systems/renderer/renderer_backend/renderer_backend_concretes/gl33/test_concrete_vbo.h"

// #include "engine/core/memory/test_choco_memory.h"

// #include "engine/core/memory/choco_memory.h"

// concrete_vbo用モジュール専用テスト制御構造体定義
// /**
//  * @brief void型の関数を強制的にNo-Opで終了させるための設定値構造体
//  *
//  */
// typedef struct test_call_control_no_op {
//     uint32_t call_count;    /**< 関数呼び出し回数 */
//     uint32_t fail_on_call;  /**< 関数を何回目の呼び出しでエラーにさせるかの設定(0なら無効で通常処理、1以上の場合はNo-Opで関数を終了させる) */
// } test_call_control_no_op_t;

// 外部公開APIテスト設定

// プライベート関数テスト設定
// static test_call_control_t s_test_config_gl33_vbo_create;               /**< gl33_vbo_create()テスト設定 */
// static test_call_control_no_op_t s_test_config_gl33_vbo_destroy;        /**< gl33_vbo_destroy()テスト設定 */
// static test_call_control_t s_test_config_gl33_vbo_bind;                 /**< gl33_vbo_bind()テスト設定 */
// static test_call_control_t s_test_config_gl33_vbo_unbind;               /**< gl33_vbo_unbind()テスト設定 */
// static test_call_control_t s_test_config_gl33_vbo_vertex_load;          /**< gl33_vbo_vertex_load()テスト設定 */
// static test_call_control_t s_test_config_gl33_vbo_vertex_subload;       /**< gl33_vbo_vertex_subload()テスト設定 */
// static test_call_control_no_op_t s_test_config_mock_glGenBuffers;       /**< mock_glGenBuffers()テスト設定 */
// static test_call_control_no_op_t s_test_config_mock_glBindBuffer;       /**< mock_glBindBuffer()テスト設定 */
// static test_call_control_no_op_t s_test_config_mock_glDeleteBuffers;    /**< mock_glDeleteBuffers()テスト設定 */
// static test_call_control_no_op_t s_test_config_mock_glBufferData;       /**< mock_glBufferData()テスト設定 */
// static test_call_control_no_op_t s_test_config_mock_glBufferSubData;    /**< mock_glBufferSubData()テスト設定 */

// 全テスト関数プロトタイプ宣言
// static void test_gl33_vbo_create(void);
// static void test_gl33_vbo_destroy(void);
// static void test_gl33_vbo_bind(void);
// static void test_gl33_vbo_unbind(void);
// static void test_gl33_vbo_vertex_load(void);
// static void test_gl33_vbo_vertex_subload(void);

// static void test_call_control_no_op_reset(test_call_control_no_op_t* config_);
// #endif

/**
 * @brief VBOモジュール内部状態管理構造体
 *
 */
struct renderer_backend_vbo {
    GLuint vbo_handle;  /**< VBO */
};

static renderer_backend_result_t gl33_vbo_create(renderer_backend_vbo_t** vertex_buffer_);
static void gl33_vbo_destroy(renderer_backend_vbo_t** vertex_buffer_);
static renderer_backend_result_t gl33_vbo_bind(const renderer_backend_vbo_t* vertex_buffer_);
static renderer_backend_result_t gl33_vbo_unbind(void);
static renderer_backend_result_t gl33_vbo_vertex_load(size_t load_size_, const void* load_data_, buffer_usage_t usage_);
static renderer_backend_result_t gl33_vbo_vertex_subload(size_t offset_, size_t size_, const void* load_data_);

static void mock_glGenBuffers(GLsizei n_, GLuint* buffer_);
static void mock_glBindBuffer(GLenum target_, GLuint buffer_);
static void mock_glDeleteBuffers(GLsizei n_, const GLuint* buffer_);
static void mock_glBufferData(GLenum target_, GLsizeiptr size_, const void* data_, GLenum usage_);
static void mock_glBufferSubData(GLenum target, GLintptr offset_, GLsizeiptr size_, const void * data_);

static const renderer_vbo_vtable_t s_gl33_vbo_vtable = {
    .vertex_buffer_create = gl33_vbo_create,
    .vertex_buffer_destroy = gl33_vbo_destroy,
    .vertex_buffer_bind = gl33_vbo_bind,
    .vertex_buffer_unbind = gl33_vbo_unbind,
    .vertex_buffer_vertex_load = gl33_vbo_vertex_load,
    .vertex_buffer_vertex_subload = gl33_vbo_vertex_subload,
};  /**< OpenGL3.3用VBO操作仮想関数テーブル */

const renderer_vbo_vtable_t* gl33_vbo_vtable_get(void) {
    // TODO: 外部からの失敗注入についてどうするか考える
    return &s_gl33_vbo_vtable;
}

/**
 * @brief VBO構造体インスタンスのメモリを確保し、VBOハンドルを生成する
 *
 * @param[out] vertex_buffer_ renderer_backend_vbo_t構造体インスタンスへのダブルポインタ
 *
 * @retval RENDERER_BACKEND_INVALID_ARGUMENT 以下のいずれか
 * - vertex_buffer_がNULL
 * - *vertex_buffer_が非NULL
 * @retval RENDERER_BACKEND_NO_MEMORY メモリ確保失敗
 * @retval RENDERER_BACKEND_UNDEFINED_ERROR メモリ確保時に不明なエラーが発生
 * @retval RENDERER_BACKEND_LIMIT_EXCEEDED メモリ管理システムのシステム使用可能範囲上限を超過
 * @retval RENDERER_BACKEND_BAD_OPERATION メモリシステム未初期化
 * @retval RENDERER_BACKEND_SUCCESS 処理に成功し、正常終了
 */
static renderer_backend_result_t gl33_vbo_create(renderer_backend_vbo_t** vertex_buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_create.call_count++;
//     if(s_test_config_gl33_vbo_create.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_create.call_count == s_test_config_gl33_vbo_create.fail_on_call) {
//             return (renderer_backend_result_t)s_test_config_gl33_vbo_create.forced_result;
//         }
//     }
// #endif
    renderer_backend_result_t ret = RENDERER_BACKEND_INVALID_ARGUMENT;

    memory_system_result_t ret_memory_system = MEMORY_SYSTEM_INVALID_ARGUMENT;

    renderer_backend_vbo_t* tmp = NULL;

    IF_ARG_NULL_GOTO_CLEANUP(vertex_buffer_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_create", "vertex_buffer_")
    IF_ARG_NOT_NULL_GOTO_CLEANUP(*vertex_buffer_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_create", "vertex_buffer_")

    ret_memory_system = memory_system_allocate(sizeof(renderer_backend_vbo_t), MEMORY_TAG_RENDERER, (void**)&tmp);
    if(MEMORY_SYSTEM_SUCCESS != ret_memory_system) {
        ret = renderer_backend_rslt_convert_choco_memory(ret_memory_system);
        ERROR_MESSAGE("gl33_vbo_create(%s) - gl33_vbo_create failed.", renderer_backend_rslt_to_str(ret));
        goto cleanup;
    }

    mock_glGenBuffers(1, &tmp->vbo_handle);

    *vertex_buffer_ = tmp;

    ret = RENDERER_BACKEND_SUCCESS;

cleanup:
// #ifdef TEST_BUILD
//     // NOTE: 将来的に仕様変更でrenderer_mem_allocate成功した後で失敗することを想定し、cleanup漏れ検出を追加
//     // ここはカバレッジ到達不可だけど許容する
//     if(RENDERER_BACKEND_SUCCESS != ret && NULL != tmp) {
//         assert(false);
//     }
// #endif
    return ret;
}

/**
 * @brief renderer_backend_vbo_t構造体インスタンスのメモリを解放し、OpenGLContext内のVBOも削除する
 *
 * @param[in,out] vertex_buffer_ renderer_backend_vbo_t構造体インスタンスへのダブルポインタ
 */
static void gl33_vbo_destroy(renderer_backend_vbo_t** vertex_buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_destroy.call_count++;
//     if(s_test_config_gl33_vbo_destroy.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_destroy.call_count == s_test_config_gl33_vbo_destroy.fail_on_call) {
//             return;
//         }
//     }
// #endif
    if(NULL == vertex_buffer_) {
        goto cleanup;
    }
    if(NULL == *vertex_buffer_) {
        goto cleanup;
    }
    mock_glDeleteBuffers(1, &(*vertex_buffer_)->vbo_handle);

    memory_system_free(*vertex_buffer_, sizeof(renderer_backend_vbo_t), MEMORY_TAG_RENDERER);

    *vertex_buffer_ = NULL;

cleanup:
    return;
}

/**
 * @brief glBindBuffer APIのラッパーAPI
 * @note 当面はglGetErrorをAPI個別に実行するつもりはないので成功するが、将来的に個別にエラー処理を行う可能性を考慮し、返り値をエラーコードにする
 *
 * @param[in] vertex_buffer_ bind対象vbo
 *
 * @retval RENDERER_BACKEND_INVALID_ARGUMENT vertex_buffer_ == NULL
 * @retval RENDERER_BACKEND_BAD_OPERATION 未初期化のvertex_buffer_が渡された
 * @retval RENDERER_BACKEND_SUCCESS 処理に成功し、正常終了
 */
static renderer_backend_result_t gl33_vbo_bind(const renderer_backend_vbo_t* vertex_buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_bind.call_count++;
//     if(s_test_config_gl33_vbo_bind.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_bind.call_count == s_test_config_gl33_vbo_bind.fail_on_call) {
//             return (renderer_backend_result_t)s_test_config_gl33_vbo_bind.forced_result;
//         }
//     }
// #endif
    renderer_backend_result_t ret = RENDERER_BACKEND_INVALID_ARGUMENT;

    IF_ARG_NULL_GOTO_CLEANUP(vertex_buffer_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_bind", "vertex_buffer_")
    IF_ARG_FALSE_GOTO_CLEANUP(0 != vertex_buffer_->vbo_handle, ret, RENDERER_BACKEND_BAD_OPERATION, renderer_backend_rslt_to_str(RENDERER_BACKEND_BAD_OPERATION), "gl33_vbo_bind", "vertex_buffer_->vbo_handle")

    mock_glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer_->vbo_handle);

    ret = RENDERER_BACKEND_SUCCESS;

cleanup:
    return ret;
}

/**
 * @brief VBO unbind処理
 *
 * @retval RENDERER_BACKEND_SUCCESS 処理に成功し、正常終了
 */
static renderer_backend_result_t gl33_vbo_unbind(void) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_unbind.call_count++;
//     if(s_test_config_gl33_vbo_unbind.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_unbind.call_count == s_test_config_gl33_vbo_unbind.fail_on_call) {
//             return (renderer_backend_result_t)s_test_config_gl33_vbo_unbind.forced_result;
//         }
//     }
// #endif
    renderer_backend_result_t ret = RENDERER_BACKEND_INVALID_ARGUMENT;

    mock_glBindBuffer(GL_ARRAY_BUFFER, 0);

    ret = RENDERER_BACKEND_SUCCESS;

    return ret;
}

/**
 * @brief GPU側頂点情報格納領域を生成し、頂点情報を転送する
 *
 * @warning 本APIを呼び出す前に必ず対象のVBOをbindしておくこと
 * @note load_data_ == NULLの場合は頂点情報格納領域の生成のみを行い、頂点情報の転送は行わない
 *
 * @param[in] load_size_ 頂点情報格納領域サイズ(byte)
 * @param[in] load_data_ 転送頂点情報配列へのポインタ
 * @param[in] usage_ バッファ使用方法種別
 *
 * @retval RENDERER_BACKEND_INVALID_ARGUMENT load_size_ == 0
 * @retval RENDERER_BACKEND_RUNTIME_ERROR 規定値外のusage_
 * @retval RENDERER_BACKEND_SUCCESS 処理に成功し、正常終了
 */
static renderer_backend_result_t gl33_vbo_vertex_load(size_t load_size_, const void* load_data_, buffer_usage_t usage_) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_vertex_load.call_count++;
//     if(s_test_config_gl33_vbo_vertex_load.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_vertex_load.call_count == s_test_config_gl33_vbo_vertex_load.fail_on_call) {
//             return (renderer_backend_result_t)s_test_config_gl33_vbo_vertex_load.forced_result;
//         }
//     }
// #endif
    renderer_backend_result_t ret = RENDERER_BACKEND_INVALID_ARGUMENT;

    IF_ARG_FALSE_GOTO_CLEANUP(0 != load_size_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_vertex_load", "load_size_")

    switch(usage_) {
    case BUFFER_USAGE_STATIC:
        mock_glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)load_size_, load_data_, GL_STATIC_DRAW);
        break;
    case BUFFER_USAGE_DYNAMIC:
        mock_glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)load_size_, load_data_, GL_DYNAMIC_DRAW);
        break;
    default:
        ERROR_MESSAGE("gl33_vbo_vertex_load(%s) - Provided usage_ is not valid.", renderer_backend_rslt_to_str(RENDERER_BACKEND_RUNTIME_ERROR));
        ret = RENDERER_BACKEND_RUNTIME_ERROR;
        goto cleanup;
    }

    ret = RENDERER_BACKEND_SUCCESS;

cleanup:
    return ret;
}

/**
 * @brief 生成済みのGPU側頂点情報格納領域に対し、転送位置を指定して頂点情報を転送する
 *
 * @warning 本APIを呼び出す前に必ず対象のVBOをbindしておくこと
 *
 * @param[in] offset_ 頂点情報格納領域の先頭から転送開始位置までのオフセット(byte)
 * @param[in] size_ 頂点情報転送サイズ(byte)
 * @param[in] load_data_ 転送する頂点情報配列へのポインタ
 *
 * @retval RENDERER_BACKEND_INVALID_ARGUMENT 以下のいずれか
 * - load_data_ == NULL
 * - size_ == 0
 * @retval RENDERER_BACKEND_SUCCESS 処理に成功し、正常終了
 */
static renderer_backend_result_t gl33_vbo_vertex_subload(size_t offset_, size_t size_, const void* load_data_) {
// #ifdef TEST_BUILD
//     s_test_config_gl33_vbo_vertex_subload.call_count++;
//     if(s_test_config_gl33_vbo_vertex_subload.fail_on_call != 0) {
//         if(s_test_config_gl33_vbo_vertex_subload.call_count == s_test_config_gl33_vbo_vertex_subload.fail_on_call) {
//             return (renderer_backend_result_t)s_test_config_gl33_vbo_vertex_subload.forced_result;
//         }
//     }
// #endif
    renderer_backend_result_t ret = RENDERER_BACKEND_INVALID_ARGUMENT;

    IF_ARG_NULL_GOTO_CLEANUP(load_data_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_vertex_subload", "load_data_")
    IF_ARG_FALSE_GOTO_CLEANUP(0 != size_, ret, RENDERER_BACKEND_INVALID_ARGUMENT, renderer_backend_rslt_to_str(RENDERER_BACKEND_INVALID_ARGUMENT), "gl33_vbo_vertex_subload", "size_")

    mock_glBufferSubData(GL_ARRAY_BUFFER, (GLintptr)offset_, (GLsizeiptr)size_, load_data_);

    ret = RENDERER_BACKEND_SUCCESS;

cleanup:
    return ret;
}

static void NO_COVERAGE mock_glGenBuffers(GLsizei n_, GLuint* buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_mock_glGenBuffers.call_count++;
//     if(s_test_config_mock_glGenBuffers.fail_on_call != 0) {
//         if(s_test_config_mock_glGenBuffers.call_count == s_test_config_mock_glGenBuffers.fail_on_call) {
//             return;
//         }
//     }
// #endif
    glGenBuffers(n_, buffer_);
}

static void NO_COVERAGE mock_glBindBuffer(GLenum target_, GLuint buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_mock_glBindBuffer.call_count++;
//     if(s_test_config_mock_glBindBuffer.fail_on_call != 0) {
//         if(s_test_config_mock_glBindBuffer.call_count == s_test_config_mock_glBindBuffer.fail_on_call) {
//             return;
//         }
//     }
// #endif
    glBindBuffer(target_, buffer_);
}

static void NO_COVERAGE mock_glDeleteBuffers(GLsizei n_, const GLuint* buffer_) {
// #ifdef TEST_BUILD
//     s_test_config_mock_glDeleteBuffers.call_count++;
//     if(s_test_config_mock_glDeleteBuffers.fail_on_call != 0) {
//         if(s_test_config_mock_glDeleteBuffers.call_count == s_test_config_mock_glDeleteBuffers.fail_on_call) {
//             return;
//         }
//     }
// #endif
    glDeleteBuffers(n_, buffer_);
}

static void NO_COVERAGE mock_glBufferData(GLenum target_, GLsizeiptr size_, const void* data_, GLenum usage_) {
// #ifdef TEST_BUILD
//     s_test_config_mock_glBufferData.call_count++;
//     if(s_test_config_mock_glBufferData.fail_on_call != 0) {
//         if(s_test_config_mock_glBufferData.call_count == s_test_config_mock_glBufferData.fail_on_call) {
//             return;
//         }
//     }
// #endif
    glBufferData(target_, size_, data_, usage_);
}

static void NO_COVERAGE mock_glBufferSubData(GLenum target, GLintptr offset_, GLsizeiptr size_, const void * data_) {
// #ifdef TEST_BUILD
//     s_test_config_mock_glBufferSubData.call_count++;
//     if(s_test_config_mock_glBufferSubData.fail_on_call != 0) {
//         if(s_test_config_mock_glBufferSubData.call_count == s_test_config_mock_glBufferSubData.fail_on_call) {
//             return;
//         }
//     }
// #endif
    glBufferSubData(target, offset_, size_, data_);
}

// #ifdef TEST_BUILD
// void test_concrete_vbo_config_reset(void) {
//     test_call_control_reset(&s_test_config_gl33_vbo_create);
//     test_call_control_no_op_reset(&s_test_config_gl33_vbo_destroy);
//     test_call_control_reset(&s_test_config_gl33_vbo_bind);
//     test_call_control_reset(&s_test_config_gl33_vbo_unbind);
//     test_call_control_reset(&s_test_config_gl33_vbo_vertex_load);
//     test_call_control_reset(&s_test_config_gl33_vbo_vertex_subload);
//     test_call_control_no_op_reset(&s_test_config_mock_glGenBuffers);
//     test_call_control_no_op_reset(&s_test_config_mock_glBindBuffer);
//     test_call_control_no_op_reset(&s_test_config_mock_glDeleteBuffers);
//     test_call_control_no_op_reset(&s_test_config_mock_glBufferData);
//     test_call_control_no_op_reset(&s_test_config_mock_glBufferSubData);
// }

// void test_concrete_vbo(void) {
//     test_gl33_vbo_create();
//     test_gl33_vbo_destroy();
//     test_gl33_vbo_bind();
//     test_gl33_vbo_unbind();
//     test_gl33_vbo_vertex_load();
//     test_gl33_vbo_vertex_subload();
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_create(void) {
//     {
//         // gl33_vbo_create() 冒頭で強制的に RENDERER_BACKEND_BAD_OPERATION を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         renderer_backend_vbo_t* vbo = NULL;

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         s_test_config_gl33_vbo_create.fail_on_call = 1U;
//         s_test_config_gl33_vbo_create.forced_result = (int)RENDERER_BACKEND_BAD_OPERATION;

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_BAD_OPERATION == ret);
//         assert(NULL == vbo);
//         assert(1U == s_test_config_gl33_vbo_create.call_count);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // vertex_buffer_ == NULL -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret = gl33_vbo_create(NULL);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // *vertex_buffer_ != NULL -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         renderer_backend_vbo_t dummy = { 0 };
//         renderer_backend_vbo_t* vbo = &dummy;

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(&dummy == vbo);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // メモリシステム未初期化 -> renderer_mem_allocate() 経由で RENDERER_BACKEND_BAD_OPERATION
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         renderer_backend_vbo_t* vbo = NULL;

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_BAD_OPERATION == ret);
//         assert(NULL == vbo);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // 下位 memory_system_allocate() 冒頭で MEMORY_SYSTEM_NO_MEMORY を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         memory_system_result_t ret_msys = MEMORY_SYSTEM_INVALID_ARGUMENT;
//         renderer_backend_vbo_t* vbo = NULL;
//         test_call_control_t config = { 0 };

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret_msys = memory_system_create();
//         assert(MEMORY_SYSTEM_SUCCESS == ret_msys);

//         test_call_control_reset(&config);
//         config.fail_on_call = 1U;
//         config.forced_result = (int)MEMORY_SYSTEM_NO_MEMORY;
//         test_memory_system_allocate_config_set(&config);

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_NO_MEMORY == ret);
//         assert(NULL == vbo);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         memory_system_destroy();
//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // 下位 memory_system_allocate() 冒頭で未定義値を返させる -> RENDERER_BACKEND_UNDEFINED_ERROR
//         renderer_backend_result_t ret = RENDERER_BACKEND_SUCCESS;
//         memory_system_result_t ret_msys = MEMORY_SYSTEM_INVALID_ARGUMENT;
//         renderer_backend_vbo_t* vbo = NULL;
//         test_call_control_t config = { 0 };

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret_msys = memory_system_create();
//         assert(MEMORY_SYSTEM_SUCCESS == ret_msys);

//         test_call_control_reset(&config);
//         config.fail_on_call = 1U;
//         config.forced_result = 99999;
//         test_memory_system_allocate_config_set(&config);

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_UNDEFINED_ERROR == ret);
//         assert(NULL == vbo);
//         assert(0U == s_test_config_mock_glGenBuffers.call_count);

//         memory_system_destroy();
//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
//     {
//         // 正常系: VBO構造体確保成功、mock_glGenBuffers() が1回呼ばれる
//         // 実 OpenGL 呼び出しを避けるため、mock_glGenBuffers() は no-op にする
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         memory_system_result_t ret_msys = MEMORY_SYSTEM_INVALID_ARGUMENT;
//         renderer_backend_vbo_t* vbo = NULL;

//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//         memory_system_destroy();

//         ret_msys = memory_system_create();
//         assert(MEMORY_SYSTEM_SUCCESS == ret_msys);

//         s_test_config_mock_glGenBuffers.fail_on_call = 1U;

//         ret = gl33_vbo_create(&vbo);
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(NULL != vbo);
//         assert(1U == s_test_config_mock_glGenBuffers.call_count);

//         // renderer_mem_allocate() のゼロ初期化により、no-op の場合は vbo_handle は 0 のまま
//         assert(0U == vbo->vbo_handle);

//         // destroy 時の実 OpenGL 呼び出しを避ける
//         s_test_config_gl33_vbo_unbind.fail_on_call = 1U;
//         s_test_config_gl33_vbo_unbind.forced_result = (int)RENDERER_BACKEND_RUNTIME_ERROR;
//         s_test_config_mock_glDeleteBuffers.fail_on_call = 1U;

//         gl33_vbo_destroy(&vbo);
//         assert(NULL == vbo);

//         memory_system_destroy();
//         test_concrete_vbo_config_reset();
//         test_choco_memory_config_reset();
//     }
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_destroy(void) {
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_bind(void) {
//     {
//         // gl33_vbo_bind() 冒頭で強制的に RENDERER_BACKEND_RUNTIME_ERROR を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         renderer_backend_vbo_t vbo = { 0 };

//         test_concrete_vbo_config_reset();

//         vbo.vbo_handle = 123U;
//         s_test_config_gl33_vbo_bind.fail_on_call = 1U;
//         s_test_config_gl33_vbo_bind.forced_result = (int)RENDERER_BACKEND_RUNTIME_ERROR;

//         ret = gl33_vbo_bind(&vbo);
//         assert(RENDERER_BACKEND_RUNTIME_ERROR == ret);
//         assert(1U == s_test_config_gl33_vbo_bind.call_count);
//         assert(0U == s_test_config_mock_glBindBuffer.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // vertex_buffer_ == NULL -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;

//         test_concrete_vbo_config_reset();

//         ret = gl33_vbo_bind(NULL);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(0U == s_test_config_mock_glBindBuffer.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // vbo_handle == 0 -> RENDERER_BACKEND_BAD_OPERATION
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         renderer_backend_vbo_t vbo = { 0 };

//         test_concrete_vbo_config_reset();

//         vbo.vbo_handle = 0U;

//         ret = gl33_vbo_bind(&vbo);
//         assert(RENDERER_BACKEND_BAD_OPERATION == ret);
//         assert(0U == s_test_config_mock_glBindBuffer.call_count);

//         test_concrete_vbo_config_reset();
//     }
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_unbind(void) {
//     {
//         // gl33_vbo_unbind() 冒頭で強制的に RENDERER_BACKEND_RUNTIME_ERROR を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;

//         test_concrete_vbo_config_reset();

//         s_test_config_gl33_vbo_unbind.fail_on_call = 1U;
//         s_test_config_gl33_vbo_unbind.forced_result = (int)RENDERER_BACKEND_RUNTIME_ERROR;

//         ret = gl33_vbo_unbind();
//         assert(RENDERER_BACKEND_RUNTIME_ERROR == ret);
//         assert(1U == s_test_config_gl33_vbo_unbind.call_count);
//         assert(0U == s_test_config_mock_glBindBuffer.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 正常系: 有効な vbo_handle なら glBindBuffer(GL_ARRAY_BUFFER, 0) を呼んで成功
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;

//         test_concrete_vbo_config_reset();

//         s_test_config_mock_glBindBuffer.fail_on_call = 1U;   // 実 OpenGL 呼び出しを避ける

//         ret = gl33_vbo_unbind();
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(1U == s_test_config_mock_glBindBuffer.call_count);

//         test_concrete_vbo_config_reset();
//     }
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_vertex_load(void) {
//     {
//         // gl33_vbo_vertex_load() 冒頭で強制的に RENDERER_BACKEND_RUNTIME_ERROR を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = { 0.0f };

//         test_concrete_vbo_config_reset();

//         s_test_config_gl33_vbo_vertex_load.fail_on_call = 1U;
//         s_test_config_gl33_vbo_vertex_load.forced_result = (int)RENDERER_BACKEND_RUNTIME_ERROR;

//         ret = gl33_vbo_vertex_load(sizeof(vertex_data), vertex_data, BUFFER_USAGE_STATIC);
//         assert(RENDERER_BACKEND_RUNTIME_ERROR == ret);
//         assert(1U == s_test_config_gl33_vbo_vertex_load.call_count);
//         assert(0U == s_test_config_mock_glBufferData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // load_size_ == 0 -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = { 0.0f };

//         test_concrete_vbo_config_reset();


//         ret = gl33_vbo_vertex_load(0U, vertex_data, BUFFER_USAGE_STATIC);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(0U == s_test_config_mock_glBufferData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 未対応 usage_ -> RENDERER_BACKEND_RUNTIME_ERROR
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = { 0.0f };

//         test_concrete_vbo_config_reset();

//         ret = gl33_vbo_vertex_load(sizeof(vertex_data), vertex_data, (buffer_usage_t)99999);
//         assert(RENDERER_BACKEND_RUNTIME_ERROR == ret);
//         assert(0U == s_test_config_mock_glBufferData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 正常系: BUFFER_USAGE_STATIC
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[9] = {
//             0.0f, 0.0f, 0.0f,
//             1.0f, 0.0f, 0.0f,
//             0.0f, 1.0f, 0.0f
//         };

//         test_concrete_vbo_config_reset();

//         s_test_config_mock_glBufferData.fail_on_call = 1U;   // 実 OpenGL 呼び出しを避ける

//         ret = gl33_vbo_vertex_load(sizeof(vertex_data), vertex_data, BUFFER_USAGE_STATIC);
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(1U == s_test_config_mock_glBufferData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 正常系: BUFFER_USAGE_DYNAMIC
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[12] = {
//             0.0f, 0.0f, 0.0f,
//             1.0f, 0.0f, 0.0f,
//             0.0f, 1.0f, 0.0f,
//             1.0f, 1.0f, 0.0f
//         };

//         test_concrete_vbo_config_reset();

//         s_test_config_mock_glBufferData.fail_on_call = 1U;   // 実 OpenGL 呼び出しを避ける

//         ret = gl33_vbo_vertex_load(sizeof(vertex_data), vertex_data, BUFFER_USAGE_DYNAMIC);
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(1U == s_test_config_mock_glBufferData.call_count);

//         test_concrete_vbo_config_reset();
//     }
// }

// // Generated by ChatGPT
// static void NO_COVERAGE test_gl33_vbo_vertex_subload(void) {
//     {
//         // gl33_vbo_vertex_subload() 冒頭で強制的に RENDERER_BACKEND_RUNTIME_ERROR を返させる
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = { 0.0f };

//         test_concrete_vbo_config_reset();

//         s_test_config_gl33_vbo_vertex_subload.fail_on_call = 1U;
//         s_test_config_gl33_vbo_vertex_subload.forced_result = (int)RENDERER_BACKEND_RUNTIME_ERROR;

//         ret = gl33_vbo_vertex_subload(0U, sizeof(vertex_data), vertex_data);
//         assert(RENDERER_BACKEND_RUNTIME_ERROR == ret);
//         assert(1U == s_test_config_gl33_vbo_vertex_subload.call_count);
//         assert(0U == s_test_config_mock_glBufferSubData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // load_data_ == NULL -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;

//         test_concrete_vbo_config_reset();

//         ret = gl33_vbo_vertex_subload(0U, sizeof(float) * 6U, NULL);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(0U == s_test_config_mock_glBufferSubData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // size_ == 0 -> RENDERER_BACKEND_INVALID_ARGUMENT
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = { 0.0f };

//         test_concrete_vbo_config_reset();

//         ret = gl33_vbo_vertex_subload(0U, 0U, vertex_data);
//         assert(RENDERER_BACKEND_INVALID_ARGUMENT == ret);
//         assert(0U == s_test_config_mock_glBufferSubData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 正常系: offset_ == 0 で部分更新
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[6] = {
//             0.0f, 0.0f, 0.0f,
//             1.0f, 0.0f, 0.0f
//         };

//         test_concrete_vbo_config_reset();

//         s_test_config_mock_glBufferSubData.fail_on_call = 1U;   // 実 OpenGL 呼び出しを避ける

//         ret = gl33_vbo_vertex_subload(0U, sizeof(vertex_data), vertex_data);
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(1U == s_test_config_gl33_vbo_vertex_subload.call_count);
//         assert(1U == s_test_config_mock_glBufferSubData.call_count);

//         test_concrete_vbo_config_reset();
//     }
//     {
//         // 正常系: offset_ != 0 で部分更新
//         renderer_backend_result_t ret = RENDERER_BACKEND_UNDEFINED_ERROR;
//         float vertex_data[3] = {
//             1.0f, 1.0f, 0.0f
//         };

//         test_concrete_vbo_config_reset();

//         s_test_config_mock_glBufferSubData.fail_on_call = 1U;   // 実 OpenGL 呼び出しを避ける

//         ret = gl33_vbo_vertex_subload(sizeof(float) * 3U, sizeof(vertex_data), vertex_data);
//         assert(RENDERER_BACKEND_SUCCESS == ret);
//         assert(1U == s_test_config_gl33_vbo_vertex_subload.call_count);
//         assert(1U == s_test_config_mock_glBufferSubData.call_count);

//         test_concrete_vbo_config_reset();
//     }
// }

// static void NO_COVERAGE test_call_control_no_op_reset(test_call_control_no_op_t* config_) {
//     config_->call_count = 0;
//     config_->fail_on_call = 0;
// }
// #endif
